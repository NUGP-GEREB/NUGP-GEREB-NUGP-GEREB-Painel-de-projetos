import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  base: '/-Painel-de-Controle-Financeiro/',
  plugins: [react()],
  build: {
    sourcemap: false,
    outDir: 'dist',
    assetsDir: 'assets',
  },
})
