import { useMemo, useState } from "react";
import { BarList } from "./components/BarList";
import { CardHelpButton } from "./components/CardHelpButton";
import { ColumnChart } from "./components/ColumnChart";
import { DonutChart } from "./components/DonutChart";
import { MetricCard } from "./components/MetricCard";
import { ProjectTable } from "./components/ProjectTable";
import { ResourceDistribution } from "./components/ResourceDistribution";
import fiocruzLogo from "./assets/Captura de tela 2026-04-14 121940.png";
import { projects } from "./data/projects";
import {
  brl,
  groupBySum,
  percent,
  sumBy,
} from "./utils/formatters";
import "./styles/dashboard.css";

const allOption = "Todos";
const supportOptions = [allOption, "Sim", "Não"];

const optionList = (values) => [
  allOption,
  ...new Set(
    values
      .filter(Boolean)
      .map((value) => String(value).trim())
      .sort((a, b) => a.localeCompare(b, "pt-BR")),
  ),
];

function groupFinancials(items, groupKey) {
  const groups = new Map();

  items.forEach((project) => {
    const label = project[groupKey] || "Não informado";
    const current = groups.get(label) || {
      label,
      value: 0,
      detailValue: 0,
      committedValue: 0,
      balanceValue: 0,
      count: 0,
    };

    current.value += Number(project.total || 0);
    current.detailValue += Number(project.realized || 0);
    current.committedValue += Number(project.committed || 0);
    current.balanceValue += Number(project.currentBalance || 0);
    current.count += 1;
    groups.set(label, current);
  });

  return [...groups.values()]
    .sort((a, b) => b.value - a.value)
    .map((item) => ({
      ...item,
      detailLabel: "Realizado",
      meta: `${percent.format(item.value ? item.detailValue / item.value : 0)} executado`,
    }));
}

const instrumentOrder = [
  "CONVÊNIO PD&I",
  "TED",
  "EMENDA PARLAMENTAR",
  "LOA",
  "CARTA ACORDO",
  "DISPENSA DE TED",
];

const instrumentColors = {
  "CONVÊNIO PD&I": "#124986",
  TED: "#2EA6A1",
  "EMENDA PARLAMENTAR": "#77C6CC",
  LOA: "#8DA0B4",
  "CARTA ACORDO": "#1B2D4A",
  "DISPENSA DE TED": "#0F4C8A",
};

const strategicAxisItems = [
  {
    label: "Atenção, Promoção, Vigilâncias, Geração de Conhecimentos e Formação para o SUS",
    value: 1005587479.05,
  },
  {
    label: "Ciência, Tecnologia, Saúde e Sociedade",
    value: 389364521.01,
  },
  {
    label: "Inovação e Complexo Produtivo em Saúde",
    value: 25092610,
  },
  {
    label: "Saúde e Sustentabilidade Socioambiental",
    value: 2450936.11,
  },
  {
    label: "Saúde, Estado e Cooperação Internacional",
    value: 1050000,
  },
];

function normalizeInstrumentType(value) {
  if (value === "EMENDAS") return "EMENDA PARLAMENTAR";
  return value || "Não informado";
}

function groupInstrumentTypes(items) {
  const groups = new Map();

  items.forEach((project) => {
    if (project.instrumentType === "EMENDAS") return;

    const label = normalizeInstrumentType(project.instrumentType);
    const current = groups.get(label) || {
      label,
      value: 0,
      detailValue: 0,
      detailTotalValue: 0,
      detailLabel: "Total",
      color: instrumentColors[label],
    };

    current.value += 1;
    current.detailValue += Number(project.total || 0);
    current.detailTotalValue += Number(project.total || 0);
    groups.set(label, current);
  });

  const knownGroups = instrumentOrder
    .map((label) => groups.get(label))
    .filter(Boolean);
  const remainingGroups = [...groups.values()]
    .filter((item) => !instrumentOrder.includes(item.label))
    .sort((a, b) => b.value - a.value);

  return [...knownGroups, ...remainingGroups];
}

const projectOptions = [allOption, ...projects.map((project) => project.id)];
const modalityOptions = optionList(
  projects.map((project) => project.instrumentType),
);
const funderOptions = optionList(projects.map((project) => project.funder));
const natureOptions = optionList(projects.map((project) => project.nature));
const axisOptions = optionList(projects.map((project) => project.axis));
const instrumentOptions = optionList(
  projects.map((project) => project.instrumentNumber),
);

function App() {
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState({
    project: allOption,
    modality: allOption,
    funder: allOption,
    nature: allOption,
    axis: allOption,
    supportTed: allOption,
    instrumentNumber: allOption,
    start: "",
    end: "",
  });

  const updateFilter = (key, value) =>
    setFilters((current) => ({ ...current, [key]: value }));

  const filteredProjects = useMemo(
    () =>
      projects.filter((project) => {
        const matchesProject =
          filters.project === allOption || project.id === filters.project;
        const matchesModality =
          filters.modality === allOption ||
          project.instrumentType === filters.modality;
        const matchesFunder =
          filters.funder === allOption || project.funder === filters.funder;
        const matchesNature =
          filters.nature === allOption || project.nature === filters.nature;
        const matchesAxis =
          filters.axis === allOption || project.axis === filters.axis;
        const matchesSupport =
          filters.supportTed === allOption ||
          (filters.supportTed === "Sim") === project.supportTed;
        const matchesInstrument =
          filters.instrumentNumber === allOption ||
          project.instrumentNumber === filters.instrumentNumber;
        const matchesStart = !filters.start || project.start >= filters.start;
        const matchesEnd = !filters.end || project.end <= filters.end;

        return (
          matchesProject &&
          matchesModality &&
          matchesFunder &&
          matchesNature &&
          matchesAxis &&
          matchesSupport &&
          matchesInstrument &&
          matchesStart &&
          matchesEnd
        );
      }),
    [filters],
  );

  const totals = useMemo(
    () => {
      const today = new Date();
      const supportTedCount = filteredProjects.filter(
        (project) => project.supportTed,
      ).length;
      const closed = filteredProjects.filter(
        (project) => new Date(`${project.end}T12:00:00`) < today,
      ).length;

      return {
        projects: filteredProjects.length,
        total: sumBy(filteredProjects, "total"),
        budgetBalance: sumBy(filteredProjects, "budgetBalance"),
        released: sumBy(filteredProjects, "released"),
        receivable: sumBy(filteredProjects, "receivable"),
        realized: sumBy(filteredProjects, "realized"),
        committed: sumBy(filteredProjects, "committed"),
        balance: sumBy(filteredProjects, "currentBalance"),
        supportTedCount,
        closed,
      };
    },
    [filteredProjects],
  );

  const executionRate = totals.total ? totals.realized / totals.total : 0;
  const releasedRate = totals.total ? totals.released / totals.total : 0;
  const availableCash = totals.released - totals.realized - totals.committed;
  const activeFilterCount = Object.values(filters).filter(
    (value) => value && value !== allOption,
  ).length;

  const topRealizedProjects = useMemo(
    () =>
      [...filteredProjects]
        .sort((a, b) => b.realized - a.realized)
        .map((project) => ({ label: project.id, value: project.realized })),
    [filteredProjects],
  );

  const topTotalProjects = useMemo(
    () =>
      [...filteredProjects]
        .sort((a, b) => b.total - a.total)
        .map((project) => ({ label: project.id, value: project.total })),
    [filteredProjects],
  );

  const instrumentItems = useMemo(
    () => groupInstrumentTypes(filteredProjects),
    [filteredProjects],
  );

  const natureItems = useMemo(
    () => groupFinancials(filteredProjects, "nature"),
    [filteredProjects],
  );

  const funderItems = useMemo(
    () => groupBySum(filteredProjects, "funder", "total"),
    [filteredProjects],
  );

  const axisItems = strategicAxisItems;

  const coordinationGroups = useMemo(
    () =>
      groupBySum(filteredProjects, "unit", "realized")
        .slice(0, 10)
        .map((item) => {
          const areaProjects = filteredProjects.filter(
            (project) => project.unit === item.label,
          );

          return {
            label: item.label,
            values: [
              sumBy(areaProjects, "realized"),
              sumBy(areaProjects, "committed"),
              Math.max(sumBy(areaProjects, "currentBalance"), 0),
            ],
          };
        }),
    [filteredProjects],
  );

  const balanceRanking = [...filteredProjects]
    .sort((a, b) => b.currentBalance - a.currentBalance)
    .slice(0, 5);

  const portfolioStats = [
    {
      label: "Projetos filtrados",
      value: "127",
      
      info: "Linhas da planilha que entram no recorte atual.",
    },
 
    {
      label: "TED de suporte",
      value: totals.supportTedCount,
      detail: `${percent.format(totals.projects ? totals.supportTedCount / totals.projects : 0)} da seleção`,
      info: "Projetos marcados como Sim em TED de Suporte.",
    },
  ];

  const resetFilters = () =>
    setFilters({
      project: allOption,
      modality: allOption,
      funder: allOption,
      nature: allOption,
      axis: allOption,
      supportTed: allOption,
      instrumentNumber: allOption,
      start: "",
      end: "",
    });

  return (
    <main className="finance-dashboard">
      <header className="topbar">
        <div className="brandline">
          <img className="brand-logo" src={fiocruzLogo} alt="Fiocruz Fundação Oswaldo Cruz" />
          <div>
            <h1>Painel de Projetos GEREB</h1>
            <p>Situação em Junho 26</p>
          </div>
        </div>
       
      </header>

      <section className="filter-shell" aria-label="Filtros da base GEREB">
        <div className="filter-summary">
          <div>
            <strong>Filtros</strong>
            <span>
              {activeFilterCount
                ? `${activeFilterCount} filtro${activeFilterCount > 1 ? "s" : ""} ativo${activeFilterCount > 1 ? "s" : ""}`
                : "Nenhum filtro ativo"}
            </span>
          </div>
          <button
            type="button"
            className="filter-toggle"
            aria-expanded={filtersOpen}
            onClick={() => setFiltersOpen((current) => !current)}
          >
            {filtersOpen ? "Ocultar" : "Mostrar"}
          </button>
        </div>
        <div className={filtersOpen ? "filter-panel is-open" : "filter-panel"}>
        <FilterSelect
          label="Projeto"
          value={filters.project}
          onChange={(value) => updateFilter("project", value)}
          options={projectOptions}
        />
        <FilterSelect
          label="Instrumento"
          value={filters.modality}
          onChange={(value) => updateFilter("modality", value)}
          options={modalityOptions}
        />
        <FilterSelect
          label="Ente financiador"
          value={filters.funder}
          onChange={(value) => updateFilter("funder", value)}
          options={funderOptions}
        />
        <FilterSelect
          label="Natureza"
          value={filters.nature}
          onChange={(value) => updateFilter("nature", value)}
          options={natureOptions}
        />
        <FilterSelect
          label="Eixo estratégico"
          value={filters.axis}
          onChange={(value) => updateFilter("axis", value)}
          options={axisOptions}
        />
        <FilterSelect
          label="Nº instrumento"
          value={filters.instrumentNumber}
          onChange={(value) => updateFilter("instrumentNumber", value)}
          options={instrumentOptions}
        />
        <FilterSelect
          label="TED suporte"
          value={filters.supportTed}
          onChange={(value) => updateFilter("supportTed", value)}
          options={supportOptions}
        />
        <label className="filter-control">
          <span>Início vigência</span>
          <input
            type="date"
            value={filters.start}
            onChange={(event) => updateFilter("start", event.target.value)}
          />
        </label>
        <label className="filter-control">
          <span>Fim vigência</span>
          <input
            type="date"
            value={filters.end}
            onChange={(event) => updateFilter("end", event.target.value)}
          />
        </label>
        <div className="filter-actions">
          <button type="button">Aplicar</button>
          <button type="button" onClick={resetFilters}>
            Limpar
          </button>
        </div>
        </div>
      </section>

      <section className="summary-board" aria-label="Resumo da carteira">
        <div className="portfolio-band">
          {portfolioStats.map((stat) => (
          <article
            className={stat.tone ? `portfolio-stat portfolio-stat--${stat.tone}` : "portfolio-stat"}
            key={stat.label}
          >
            <CardHelpButton
              title={stat.label}
              description={stat.info}
              detail={stat.detail}
              value={stat.value}
            />
            <span>{stat.label}</span>
            <strong>{stat.value}</strong>
          </article>
          ))}
        </div>

        <div className="kpi-row kpi-row--financial">
        <MetricCard
          label="Valor total dos instrumentos"
          value= "R$ 1.465.211.460,06"
          info="Soma da coluna Valor Total Instrumento Contratual."
          detail="Soma contratual"
          tone="blue"
        />
       
        <MetricCard
          label="Recurso liberado"
          value=" R$ 639.179.572,37"
          info="Total que já foi disponibilizado para os projetos."
          detail={`${percent.format(releasedRate)} do contratado`}
          tone="green"
        />
        <MetricCard
          label="Recurso a receber"
          value="R$ 863.684.583,50"
          info="Valor previsto que ainda não foi liberado."
          detail="Previsão ainda não liberada"
          tone="amber"
        />
        <MetricCard
          label="Total realizado"
          value="R$ 667.327.428,72"
          info="Soma executada ou gasta pelos projetos."
          detail={`${percent.format(executionRate)} executado`}
          tone="violet"
        />
        <MetricCard
          label="Total comprometido"
          value="R$ 138.499.218,72"
          info="Compromissos registrados, ainda não necessariamente pagos."
          detail="Compromissos registrados"
          tone="red"
        />
        <MetricCard
          label="Saldo total atual"
          value="R$ 122.339.433,51"
          info="Saldo financeiro atual informado na base."
          detail={`${brl.format(availableCash)} caixa livre`}
          tone={totals.balance < 0 ? "red" : "green"}
        />
        </div>
      </section>

      <section className="dashboard-grid">
        <ResourceDistribution />
        <DonutChart
          title="Tipos de Instrumentos"
          info="Mostra a distribuição dos projetos por tipo de instrumento contratual."
          items={
            instrumentItems.length
              ? instrumentItems
              : [{ label: "Sem dados", value: 1 }]
          }
          detailTitle="Detalhamento"
          showDetailCount
          showDetailFacts={false}
          showDetailTotal
          valueType="count"
        />
      </section>

      <ColumnChart
        title="Realizado, Comprometido e Saldo por Coordenação"
        subtitle="Concentração financeira das coordenações com maior execução"
        info="Compara as coordenações com maior execução para mostrar onde estão concentrados os valores realizados, os compromissos assumidos e os saldos disponíveis."
        groups={coordinationGroups}
      />

      <section className="charts-row">
        <BarList
          title="Projetos por Total Realizado"
          subtitle="Ranking de execução financeira"
          info="Lista os projetos com maior total realizado. Serve para identificar quais projetos mais executaram recursos dentro do filtro selecionado."
          items={topRealizedProjects}
          limit={10}
          expandable
          wideLabels
        />
        <BarList
          title="Projetos por Valor Contratado"
          subtitle="Ranking do valor total do instrumento"
          info="Lista os maiores projetos pelo valor total contratado. Ajuda a separar porte contratual de execução financeira."
          items={topTotalProjects}
          limit={10}
          expandable
          wideLabels
        />
      </section>

      <section className="dashboard-grid dashboard-grid--support">
        <BarList
          title="Ente Financiador"
          subtitle="Valor total contratado por financiador"
          info="Mostra quais entes financiadores concentram o maior valor contratado na carteira filtrada."
          items={funderItems}
          limit={8}
          expandable
          wideLabels
        />
        <DonutChart
          title="Naturezas dos Projetos"
          subtitle="Valor total contratado por natureza"
          info="Mostra como o valor contratado se divide por natureza do projeto, como ensino, pesquisa, extensão e desenvolvimento institucional."
          items={
            natureItems.length ? natureItems : [{ label: "Sem dados", value: 1 }]
          }
          detailTitle="Detalhamento"
          showDetailCount
          showDetailFacts={false}
          showDetailTotal
        />
      </section>

      <section className="dashboard-grid dashboard-grid--support dashboard-grid--single">
        <BarList
          title="Eixo Mapa Estratégico Fiocruz"
          subtitle="Valor total contratado por eixo"
          info="Organiza o valor contratado pelos eixos estratégicos informados na planilha, ajudando a ver quais temas concentram mais recursos."
          items={axisItems}
          limit={6}
          fullValues
          roomyLabels
        />
      </section>

      <ProjectTable projects={filteredProjects} />

      <section className="ranking-strip">
        <h2>
          Ranking de projetos com maior saldo disponível
          <span>(Saldo total atual)</span>
        </h2>
        <div>
          {balanceRanking.map((project, index) => (
            <article key={project.id}>
              <strong>{index + 1}</strong>
              <span>{project.id}</span>
              <b>{brl.format(project.currentBalance)}</b>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function FilterSelect({ label, value, onChange, options }) {
  return (
    <label className="filter-control">
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        {options.map((option) => (
          <option key={option}>{option}</option>
        ))}
      </select>
    </label>
  );
}

export default App;
